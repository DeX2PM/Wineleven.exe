 __      __.__              .__                             
/  \    /  \__| ____   ____ |  |   _______  __ ____   ____  
\   \/\/   /  |/    \_/ __ \|  | _/ __ \  \/ // __ \ /    \ 
 \        /|  |   |  \  ___/|  |_\  ___/\   /\  ___/|   |  \
  \__/\  / |__|___|  /\___  >____/\___  >\_/  \___  >___|  /
       \/          \/     \/          \/          \/     \/ 

[ENG]
Malware name - Wineleven.exe
Type - Destructive
Start in own risk Creator DeX2PM not respons for any damage to PC
This malware can kill MBR and crash system malware can delete files
After start you can see GDI effects (noskid) and loud bytebeat sounds before effect malware starts an administrator rules and close UAC
(recommended start on a Virtual Machine)

[RUS]
Название вируса - Wineleven.exe
Тип - Деструктивный
Запуская вы рискуете потерять систему, файлы, МБР
Разработчик не в ответе за ЛЮБЫЕ проблемы с системой
Вирус может убить систему вместе с МБР стереть файлы и все другое
После запуска вирус обходит защиту УАК и запускается с правами администратора после этого вы увидите ГДИ эффекты и услышите Байтбит музыку
(рекомендуется запускать на виртуальной машине)
                                                                                                                       